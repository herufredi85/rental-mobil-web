<?php
 require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
 
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
 
$sheet->setCellValue('A1', 'No');
$sheet->setCellValue('B1', 'NAMA LENGKAP');
$sheet->setCellValue('C1', 'ALAMAT');
$sheet->setCellValue('D1', 'JENIS KELAMIN');
$sheet->setCellValue('E1', 'EMAIL');
$sheet->setCellValue('F1', 'KONTAK');
$writer = new Xlsx($spreadsheet);
$writer->save('xlsx/Data karyawan.xlsx');
echo "<script>window.location = '".base_url()."xlsx/Data karyawan.xlsx'</script>";
?>